<?php
require_once __DIR__.'/vendor/autoload.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>My Game</title>
  <!-- echo Bower->css() -->
  <link rel="stylesheet" href="bower_components/bootstrap-css/css/bootstrap.css" type="text/css" />
  
  <!-- echo Bower->js() -->
  <script src="bower_components/phaser/build/phaser.js"></script>
  <script src="bower_components/system.js/dist/system.js"></script>
  <script>
    System.config({
      baseURL: '/js'
    });
    System.import('system-init.js');
  </script>
  
  <style>
    #phaser-example canvas {
      padding: 0;
      margin: auto;
      display: block;
      width: 800px;
      height: 600px;
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
  }
  </style>
</head>
<body>

<div class="container">
  <div id="phaser-example"></div>
</div>

</body>
</html>

