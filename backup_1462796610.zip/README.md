# 2D-Side-Scroller-with-Tile-Map-with-Phaser
A basic 2D side scroller setup for Phaser 2d
