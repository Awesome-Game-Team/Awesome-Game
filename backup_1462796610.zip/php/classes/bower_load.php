<?php

class Bower {
    
    private $bower_dir = false,
    $bower_files = array();
    /*
        [
            package_name => {
                css -> []
                js -> []
            }
        ]
    */
    
    public function __construct($dir)
    {
        if( is_string($dir) ){
            $this->bower_dir = $dir;
            $this->load_bower_files();
        } else {
            return false; /* Show error */
        }
    }
    
    public function css()
    {
        
    }
    
    public function js()
    {
        
    }
    
    /**/
    private function load_bower_files()
    {
        
    }
    
}

?>