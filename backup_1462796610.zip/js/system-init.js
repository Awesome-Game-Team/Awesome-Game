console.log("System init");

System.import("fbk.js");
System.import("main.js");
